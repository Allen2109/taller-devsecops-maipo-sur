# Ficha de blindaje · Maipo Sur

**Curso:** SISTEMA AUTO DEVSECOPS LAB 1. **Sector:** agua potable, caso base ficticio. **Fecha:** 09-10-2026.  
**Equipo:** Miguel Briceño (desarrollo), Franco Perez (pipeline), Marcela Manzor (operación y auditoría IA). Distribución propuesta para tres integrantes.

## Sistema y dibujo

El lector muestra una lectura simulada de cloro. Una alteración o interrupción en una planta real podría afectar el tratamiento del agua y dejar al turno sin información confiable. [DFD digital](docs/arquitectura/dfd.png) y [archivo editable](docs/arquitectura/dfd.drawio). Se adjunta la [fotografía del dibujo en papel](evidencias/diagrama-papel.jpg), proporcionada por el grupo el 14-10-2026.

## Tres amenazas priorizadas

| Amenaza | STRIDE | Impacto físico | Control |
|---|---|---|---|
| Credencial publicada | S/I | Suplantar al turno y alterar o bloquear supervisión del tratamiento | Gitleaks, secreto fuera del código, sustitución simulada comprobada; revocación antes de operación real |
| Entrada convertida en comando | T/E | Ejecutar acciones indebidas y producir lecturas u órdenes alteradas | Semgrep y validación de entradas; lector sin shell |
| Panel expuesto a cualquier origen | E/D | Impedir el acceso del turno y retrasar la respuesta ante tratamiento incorrecto | Trivy config y modelo de acceso restringido |

## Controles y evidencia

Activados: código propio (Gitleaks y Semgrep), dependencias (Trivy y OSV) y configuración (Trivy config). Incluye SBOM CycloneDX. [Ejecuciones verificadas](evidencias/VALIDACION.md); [Actions](https://github.com/miguelbriceno-sys/Taller-de-infraestructura-critica/actions/workflows/seguridad.yml). Las pruebas negativas demuestran detección sin ejecutar los parches.

## Hallazgos y decisiones

| Hallazgo | Gravedad | Decisión y motivo | Responsable propuesto / fecha |
|---|---|---|---|
| Secreto ficticio en config del escenario inicial | Alta | Corregir: referencia a variable; conservar fallo solo en rama didáctica | Miguel / 09-10-2026 |
| Shell, TLS desactivado y paquete no aprobado | Alta | Rechazar el parche y usar lector local validado | Marcela / 09-10-2026 |
| Regla abierta de red en prueba negativa | Alta | Corregir el modelo; confirmar detección automática | Franco / 09-10-2026 |
| Sin despliegue, segmentación ni rollback industrial | Alta en planta real | Postergar implementación real; no autorizar puesta en planta | Franco y Marcela / revisión 16-10-2026 |

## Veredicto sobre IA

**Rechazado técnicamente.** Paquete: PyPI devolvió HTTP 404, sin origen aprobado. Entradas: concatena host y registro en shell. Protección: `verify=False` desactiva validación TLS. Destino: `TELEMETRIA` no definido en el fragmento; envío no solicitado. [Evidencia del análisis](docs/auditoria-ia/veredicto.md).

**Explicación para operación:** Este cambio podría permitir que una entrada manipulada ejecute órdenes con los permisos del lector y afectar la supervisión del tratamiento del agua. Además, enviaría las lecturas a un destino sin justificar y sin comprobar correctamente su certificado, por lo que rechazamos la propuesta hasta corregir esos riesgos.

El borrador se elaboró con asistencia de IA y se corrigió para expresar consecuencias posibles, sin inventar el destino de `TELEMETRIA`. La ratificación personal corresponde al grupo.

## Pendientes y reproducción

Antes de una planta real: credenciales rotadas y auditadas, autorización por rol, segmentación efectiva, pruebas con fabricante, límites de consulta, auditoría protegida y rollback. Para la evaluación presencial: fotografía del dibujo ya adjunta; [práctica alternativa de Agent Breaker](evidencias/agent-breaker/README.md) realizada: nivel 1 con 100/100 y cuatro intentos rechazados en el nivel 2. No declaramos ayuda a otro grupo.

```bash
python scripts/install_tools.py && python -m pip install --require-hashes -r tools/requirements.lock
bash scripts/analizar.sh
python scripts/pruebas_controles.py
```

## Práctica de protección de información

El 14-10-2026 realizamos Cycling Coach de Agent Breaker tras la redirección del enlace de Gandalf. El nivel 1 fue superado con 100/100 y el nivel 2 rechazó cuatro solicitudes con 0/100. El [registro de la práctica](evidencias/agent-breaker/README.md) conserva diez capturas, solicitudes, análisis y límites. No se afirma equivalencia académica con Gandalf.
